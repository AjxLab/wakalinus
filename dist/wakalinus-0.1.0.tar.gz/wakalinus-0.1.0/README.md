wakalinus
=========

A simple sentiment analysis utility for Japanese.


## Requirements
* Python 3


## Installation
```sh
$ pip install wakalinus
```

